<template>
  <div>注册结果</div>
</template>
